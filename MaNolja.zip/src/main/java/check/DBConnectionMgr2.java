package check;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

public class DBConnectionMgr {
	
	   static {
	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	        } catch (ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	    }


    private static final String JDBC_URL = "jdbc:mysql://localhost:3307/jsp_project";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Yju1234!";
    private static final String INSERT_RESERVATION_QUERY = "INSERT INTO booking (sdate, edate, room_idx, resev_at, resev_price, resev_people, mem_idx) VALUES (?, ?, ?, ?, ?, ?, ?)";

    public DBConnectionMgr() {
        // 생성자
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);
    }

    public boolean insertReservation(String start_date, String end_date, int room_idx,  int room_price, int people, int mem_idx) {
        boolean success = false;

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // DB 연결
            connection = getConnection();
            
            // 현재 시간을 Timestamp로 변환
            Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());

            // PreparedStatement 설정
            preparedStatement = connection.prepareStatement(INSERT_RESERVATION_QUERY);
            preparedStatement.setString(1, start_date);
            preparedStatement.setString(2, end_date);
            preparedStatement.setInt(3, room_idx);
            preparedStatement.setTimestamp(4, currentTimestamp);
            preparedStatement.setInt(5, room_price);
            preparedStatement.setInt(6, people);
            preparedStatement.setInt(7, mem_idx);

            // 쿼리 실행
            int rowsAffected = preparedStatement.executeUpdate();

            // 성공적으로 실행되면 rowsAffected는 1 이상의 값이 됨
            success = (rowsAffected > 0);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 리소스 해제
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return success;
    }
}